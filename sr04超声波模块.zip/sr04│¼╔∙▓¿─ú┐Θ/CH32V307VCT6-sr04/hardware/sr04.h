#ifndef __SR04_H
#define __SR04_H
#include "ch32v30x.h"

void Timer2_Config(void);
void Ultrasonic_Config(void);

#endif
