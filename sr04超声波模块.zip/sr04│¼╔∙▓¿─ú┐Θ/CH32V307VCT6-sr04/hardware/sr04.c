#include "sr04.h"
#include "ch32v30x.h"
void Ultrasonic_Config(void){
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;   //Trig
    //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;    //�����������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB,&GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;   //ECHO,����
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //��Ϊ����
    GPIO_Init(GPIOB,&GPIO_InitStructure);
    printf("Ultrasonic_Config ready\r\n");
}
void Timer2_Config(void){
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
    TIM_TimeBaseInitStructure.TIM_Prescaler = 143;//ch32v307��APB1���λ144MHz����144��Ϊ1MHz����1us
    TIM_TimeBaseInitStructure.TIM_Period = 49999;   //144*50000/144 = 50000us = 50ms.
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
    TIM_ClearFlag(TIM2,TIM_FLAG_Update);    //���²����ж�
    printf("Timer2_Config ready\r\n");
}

